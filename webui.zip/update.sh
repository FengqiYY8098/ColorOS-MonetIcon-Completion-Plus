#!/system/bin/sh

# === 路径配置 ===
MOD_DIR="/data/adb/modules/ThemedIconCompletion"
WEB_ROOT="$MOD_DIR/webroot"
VERSION_FILE="$WEB_ROOT/version"

# 【修正点】这里不再使用 WEB_ROOT，而是直接指定 data/adb 下的独立目录
CACHE_DIR="/data/adb/uxicons_cache_tmp"

# 下载的 zip 路径
ZIP_FILE="$CACHE_DIR/uxicons.zip"

# 目标路径
TARGET_A="$MOD_DIR/data/oplus/uxicons/"
TARGET_B="$MOD_DIR/my_product/media/theme/uxicons/"

# 传入的新版本号
NEW_VERSION="$1"

# === 开始执行 ===
echo ">>> 脚本开始执行 (Root)..."
echo ">>> 缓存目录: $CACHE_DIR"

# 1. 检查文件是否存在
if [ ! -f "$ZIP_FILE" ]; then
    echo "错误: 在缓存目录找不到 uxicons.zip"
    exit 1
fi

echo ">>> 正在解压..."
# 解压
unzip -o "$ZIP_FILE" -d "$CACHE_DIR" > /dev/null 2>&1

if [ $? -ne 0 ]; then
    echo "错误: 解压失败，文件可能损坏"
    # 失败也清理，防止残留
    rm -rf "$CACHE_DIR"
    exit 1
fi

echo ">>> 正在合并图标..."
mkdir -p "$TARGET_A"
mkdir -p "$TARGET_B"

# 复制文件
cp -rf "$CACHE_DIR/uxicons/"* "$TARGET_A"
cp -rf "$CACHE_DIR/uxicons/"* "$TARGET_B"

echo ">>> 更新版本号..."
if [ ! -z "$NEW_VERSION" ]; then
    echo "$NEW_VERSION" > "$VERSION_FILE"
fi

echo ">>> 清理临时目录..."
# 【关键】删除我们在 data/adb 下创建的临时目录
rm -rf "$CACHE_DIR"

echo ">>> 刷新系统缓存..."
rm -rf /data/data/com.heytap.theme/cache/*
rm -rf /data/data/com.oplus.themestore/cache/*
rm -rf /data/user_de/0/com.android.launcher/cache/*

echo ">>> 全部完成 (Success)"
exit 0